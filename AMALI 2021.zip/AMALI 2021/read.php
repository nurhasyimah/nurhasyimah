<?php
require "koneksi.php";
$sql     = " SELECT * FROM table_crud";
$execute = mysqli_query($koneksi , $sql);


?>

<!DOCTYPE html>
<html>
<head>
  <title>Read Php</title>
  <style>
table {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  background-color: tomato;
}

th, td {
  text-align: left;
  padding: 16px;
}
</style>
</head>
<body>
  <a href="add.php">Tambah Data</a>
  <table border="1" width="50%">
    <thead>
      <th>id</th>
      <th>nama</th>
      <th>kelas</th>
      <th>action</th>
    </thead>
    <?php while($result = mysqli_fetch_assoc($execute)){ ?>
    <tr>
      <td><?= $result['id'] ?></td>
      <td><?= $result['nama'] ?></td>
      <td><?= $result['kelas'] ?></td>
      <td>
        <a href="update.php?id=<?= $result['id'] ?>">Update</a>  

        <a href="delete.php?id=<?= $result['id'] ?>">Delete</a></td>
    </tr>
  <?php }?> 
  </table>

</body>
</html>