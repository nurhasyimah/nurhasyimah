<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>LOGIN</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<script src="https://kit.fontawesome.com/376cba891b.js" crossorigin="anonymous"></script>
</head>
<body>
	
	<div class="login">
		<div class="avatar">
			<i class="fa fa-user"></i>
		</div>
		<h2>Login Form</h2>

		<div class="box-login">
			<i class="fas fa-id"></i>
			<input type="text" placeholder="Id">
		</div>
		<br>
		<div class="box-login">
			<i class="fas fa-nama"></i>
			<input type="text" placeholder="Nama">
		</div>
		<br>
		<div class="box-login">
			<i class="fas fa-kelas"></i>
			<input type="text" placeholder="Kelas">
		</div>
		<br>
		<button type="submit" class="btn-login">
			Login
		</button>
		<br>
		<br>
		<div class="bottom">
			<a href="tambah.php">Register</a>
			<br>
			<br>
			<a href="">Forgot Your Id ?</a>
		</div>
	</div>

</body>
</html>